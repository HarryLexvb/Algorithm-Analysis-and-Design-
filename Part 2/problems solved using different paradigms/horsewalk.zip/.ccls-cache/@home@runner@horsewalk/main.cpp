#include <iostream>
#include <cmath>

using namespace std;

int move_x[8] = {1, 1, 2, 2, -1, -1, -2, -2};
int move_y[8] = {2, -2, 1, -1, 2, -2, 1, -1};

void printSolution(int n, int **arr){
    for(int i = 0; i < n; ++i) {
        for(int j = 0; j < n; ++j) {
            cout << *(*(arr + i) + j ) << "\t";
        }
        cout<<endl;
    }
}

bool isSafe(int x, int y, int **arr, int n){
    //Verífica que no se sobrepase los limites de la matriz y que la posición a verificar no se haya tomado previamente.
    if(x < 0 or x > n - 1 or y < 0 or y > n - 1 or arr[x][y] > 0)
        return false;
    return true;
}

int getDegree(int **arr, int n, int x, int y){
    //Verifica los caminos posibles, en caso de no tener caminos posibles se retorna -1
    int res = -1;
    for(int i = 0; i < 8; ++i)
        if(isSafe(x + move_x[i], y + move_y[i], arr, n))
            res += 1;
    return res;
}

bool solve(int n, int **arr, int curr_x, int curr_y, int pos){
    int id1 = -1;
    int min_degree1 = n + 1;
    arr[curr_x][curr_y] = pos;
    if(pos == pow(n,2)){
        printSolution(n, arr); //Encuentra la solución, imprime el array
        return true;
    }
    for(int i = 0; i < 8; ++i){
        int new_x = curr_x + move_x[i];
        int new_y = curr_y + move_y[i];
        if(isSafe(new_x, new_y, arr, n)){
            int degree = getDegree(arr, n, new_x, new_y);
            if(degree <= min_degree1){
                min_degree1 = degree;
                id1 = i;
            }
        }
    }

    if(id1 == -1){
        cout << "no hay solucion " << endl;
        return false;
    }
    int nx = curr_x + move_x[id1];
    int ny = curr_y + move_y[id1];

    solve(n, arr, nx, ny, pos + 1);
    return false;
}


void horse_6(int n, int x, int y){
    int pos_x = x;
    int pos_y = y;

    int** matrix = new int*[n];

    for(int i = 0; i < n; ++i) {
        *(matrix + i) = new int[n];
        for(int j = 0; j < n; ++j) {
            *(*(matrix + i) + j ) = -1;
        }
    }
    //printSolution(n, matrix);
    int pos = 1; //Contador de las posiciones tomadas, se va reemplazando en la matriz.
    solve(n, matrix, pos_x, pos_y, pos);
}

int main(){
    horse_6(8, 0, 0);
}