#include <iostream>
#include <map>
#include <list>
#include <queue>

using namespace std;

template <typename T>
class Graph
{
private:
    map<T, list<T>> l;

public:
    void addEdge(T x, T y){
        l[x].push_back(y);
        l[y].push_back(x);
    }

    void bfs(T src){
        map<T, int> visited;
        queue<T> q;

        q.push(src);
        visited[src] = true;

        cout << "BFS: ";

        while (!q.empty()){
            T node = q.front();
            q.pop();
            cout << node << " ";
            for ([[maybe_unused]] auto nbr : l[node]){
                if (!visited[nbr]){
                    q.push(nbr);
                    visited[nbr] = true;
                }
            }
        }
        cout << endl;
    }

    void print(){
        for ([[maybe_unused]] const auto& node : l){
            cout << node.first << " -> ";
            for (T nbr : node.second)
                cout << nbr << " ";
            cout << endl;
        }
    }
};

int main()
{
    Graph<int> g;
    g.addEdge(0, 1);
    g.addEdge(1, 2);
    g.addEdge(2, 3);
    g.addEdge(3, 4);
    g.addEdge(4, 5);
    g.addEdge(0, 3);
    g.print();
    g.bfs(0);
}

/*
  1  crea una queue para hacer BFS
    2  crea un mapa para marcar los nodos visitados
    3  agrega el nodo inicial a la queue
    4  mientras la queue no este vacia
        5  saca el nodo de la queue
        6  imprime el nodo
        7  para cada nodo adyacente
            8  si no fue visitado
                9  agrega el nodo a la queue
                10  marca el nodo como visitado
    11  imprime la queue

    complejidad temporal: O(V + E)
 */