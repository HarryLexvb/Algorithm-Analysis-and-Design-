#include <iostream>
#include <ctime>
using namespace std; 

const int n = 10, MAXIMO = 10;
    
void bubble_sort(int n, int *arr){

  /*
  Worst case time complexity:   O(n^2 )
  Best case time complexity:    O(n)
  Average time complexity:  O(n^2 )
  Space complexity: O(1)
  */

  int temp; 

  for(int i = 0; i < n; ++i) {
     for(int j = i + 1; j < n; ++j)
     {
        if(arr[j] < arr[i]){
          /*temp = arr[i];
          arr[i] = arr[j];
          arr[j] = temp;*/
          swap(arr[i], arr[j]); 
      }
    }
  }
  
}

void selection_sort(int n, int *arr){

  // O(n^2 )
  int min; 
  
  for (int i = 0; i < n-1; ++i){
    
    min = i; 
    for (int j = i+1; j < n; ++j) 
      
      if (arr[j] < arr[min]) 
        min = j; 
    
      swap(arr[min], arr[i]);   
    } 
}

void insertion_sort(int n, int *arr){

  // O(n 2)
  int key; 
  for (int i = 1; i < n; i++){
    key = arr[i];
    int j = i - 1;
    while (j >= 0 and arr[j] > key){
      arr[j + 1] = arr[j];
      j = j - 1;
    }
    arr[j + 1] = key;
  }

}

void heapify(int *arr, int n, int i){
    int largest = i; 
    int l = 2 * i + 1; 
    int r = 2 * i + 2;
 
    // Si el hijo izquierdo es más grande que la raíz
    if (l < n && arr[l] > arr[largest])
        largest = l;
 
    // Si el hijo derecho es más grande que el más grande hasta ahora
    if (r < n && arr[r] > arr[largest])
        largest = r;
 
    // Si el mayor no es la raíz
    if (largest != i) {
        swap(arr[i], arr[largest]);
 
        // Acumula recursivamente el subárbol afectado
        heapify(arr, n, largest);
    }

}
 
void heap_sort(int n, int *arr){

    // reorganizar el array
    for (int i = n / 2 - 1; i >= 0; --i)
        heapify(arr, n, i);
 
    // extreae un elemento uno por uno
    for (int i = n - 1; i > 0; --i) {
        // Mover la raíz actual al final
        swap(arr[0], arr[i]);
 
        heapify(arr, i, 0);
    }

    cout << endl; 
    for(int i = 0; i < n; ++i) 
        cout <<arr[i]<<"\t";
}
////////////////////////////////////////////////////////////////////////////////////////////////////
int partition (int *arr, int start, int end){
    int pivot = arr[end]; // pivote
    int i = (start - 1); // Índice del elemento más pequeño e indica la posición correcta del pivote encontrado hasta el momento
 
    for (int j = start; j <= end - 1; ++j)
    {
        // Si el elemento actual es más pequeño que el pivote
        if (arr[j] < pivot)
        {
            ++i; // índice de incremento del elemento más pequeño
            swap(arr[i], arr[j]);
        }
    }
    swap(arr[i + 1], arr[end]);
    return (i + 1);
}

void quickSort(int *arr, int start, int end){
    if (start < end){
        
        int pi = partition(arr, start, end);
 
        // ordenar por separado los elementos anteriores
        quickSort(arr, start, pi - 1);
        // prticion y despues de la particion 
        quickSort(arr, pi + 1, end);
    }

}
////////////////////////////////////////////////////////////////////////////////////////////////////
void merge(int *array, int const left, int const mid, int const right){

    auto const subArrayOne = mid - left + 1;
    auto const subArrayTwo = right - mid;
  
    // creamos arreglos temporales 
    auto *leftArray = new int[subArrayOne],
         *rightArray = new int[subArrayTwo];
  
    // copiarmos los datos a arreglos temporales leftArray[] y rightArray[]
    for (auto i = 0; i < subArrayOne; i++)
        leftArray[i] = array[left + i];
    for (auto j = 0; j < subArrayTwo; j++)
        rightArray[j] = array[mid + 1 + j];
  
    auto indexOfSubArrayOne = 0, // Índice inicial del primer subarreglo
        indexOfSubArrayTwo = 0; // Índice inicial del segundo subarreglo
    int indexOfMergedArray = left; // Índice inicial de matriz fusionada
  
    // Combinar los arreglos temporales de nuevo en[left..right]
    while (indexOfSubArrayOne < subArrayOne && indexOfSubArrayTwo < subArrayTwo) {
        if (leftArray[indexOfSubArrayOne] <= rightArray[indexOfSubArrayTwo]) {
            array[indexOfMergedArray] = leftArray[indexOfSubArrayOne];
            indexOfSubArrayOne++;
        }
        else {
            array[indexOfMergedArray] = rightArray[indexOfSubArrayTwo];
            indexOfSubArrayTwo++;
        }
        indexOfMergedArray++;
    }
    // Copie los elementos restantes de left[]
    while (indexOfSubArrayOne < subArrayOne) {
        array[indexOfMergedArray] = leftArray[indexOfSubArrayOne];
        indexOfSubArrayOne++;
        indexOfMergedArray++;
    }
    // Copie los elementos restantes de rifht[]
    while (indexOfSubArrayTwo < subArrayTwo) {
        array[indexOfMergedArray] = rightArray[indexOfSubArrayTwo];
        indexOfSubArrayTwo++;
        indexOfMergedArray++;
    }
}
  
void mergeSort(int *array, int const begin, int const end){
    if (begin >= end)
        return; // retorna recursivamente 
  
    auto mid = begin + (end - begin) / 2;
    mergeSort(array, begin, mid);
    mergeSort(array, mid + 1, end);
    merge(array, begin, mid, end);
}


int particion(int arreglo[], int izquierda, int derecha) {
  // Elegimos el pivote, es el primero
  int pivote = arreglo[izquierda];
  // Ciclo infinito
  while (1) {
    // Mientras cada elemento desde la izquierda esté en orden (sea menor que el
    // pivote) continúa avanzando el índice
    while (arreglo[izquierda] < pivote) {
      izquierda++;
    }
    // Mientras cada elemento desde la derecha esté en orden (sea mayor que el
    // pivote) continúa disminuyendo el índice
    while (arreglo[derecha] > pivote) {
      derecha--;
    }
    /*
    Si la izquierda es mayor o igual que la derecha significa que no
    necesitamos hacer ningún intercambio
    de variables, pues los elementos ya están en orden (al menos en esta
    iteración)
    */
    if (izquierda >= derecha) {
      // Indicar "en dónde nos quedamos" para poder dividir el arreglo de nuevo
      // y ordenar los demás elementos
      return derecha;
    } else {//Nota: yo sé que el else no hace falta por el return de arriba, pero así el algoritmo es más claro
      /*
      Si las variables quedaron "lejos" (es decir, la izquierda no superó ni
      alcanzó a la derecha)
      significa que se detuvieron porque encontraron un valor que no estaba
      en orden, así que lo intercambiamos
      */
      swap(arreglo[izquierda], arreglo[derecha]);
      /*
      Ya intercambiamos, pero seguimos avanzando los índices
      */
      izquierda++;
      derecha--;
    }
    // El while se repite hasta que izquierda >= derecha
  }
}

void qui(int arreglo[], int izquierda, int derecha) {
  if (izquierda < derecha) {
    int indiceParticion = particion(arreglo, izquierda, derecha);
    qui(arreglo, izquierda, indiceParticion);
    qui(arreglo, indiceParticion + 1, derecha);
  }
}

int main(){

    unsigned t0, t1;
    t0=clock();
        
    int arr[n] = {0};
    srand(time(0));
      
    for (int i = 0; i < n; ++i )
        arr[i] = rand() % MAXIMO;

    /*for (int i = 0; i < n; ++i ){
       cout << arr[i] << "\t";
    }*/
      
    bubble_sort(n, arr); 
    //selection_sort(n, arr);
    //insertion_sort(n, arr);  
    //heap_sort(n, arr); 
    //quickSort(arr, 0, n - 1);
    //mergeSort(arr, 0, n - 1);
    //qui(arr, 0, n - 1);
  

    cout << endl; 
    for(int i = 0; i < n; ++i) 
        cout <<arr[i]<<"\t";

    t1 = clock();
    double time = (double(t1-t0)/CLOCKS_PER_SEC);
    cout << "\n\nExecution Time: " << time << endl;
      
}

