#include <iostream>
using namespace std;

//Complejidad temporal: O(2^n) esto se debe a los subproblemas redundantes que se generan en cada paso de la recursión.

int knapSack_bruteforce(int W, int *wt, int *value, int n){
    if (n == 0 or W == 0)
        return 0;

    if (wt[n - 1] > W)
        return knapSack_bruteforce(W, wt, value, n - 1);

    else
        return max(value[n - 1] + knapSack_bruteforce(W - wt[n - 1], wt, value, n - 1), knapSack_bruteforce(W, wt, value, n - 1));
}

int main()
{
    int val[] = { 50, 90, 110 };
    int wt[] = { 20, 30, 40 };
    int W = 60;
    int n = sizeof(val) / sizeof(val[0]);
    cout << knapSack_bruteforce(W, wt, val, n);
}

/*
Dados los pesos y valores de los elementos, w y v, respectivamente, ¿se puede elegir un subconjunto de elementos x subconjunto propio {1,2,...n} que satisfagan las siguientes restricciones?

Una solución de 'Sí' o 'No' al problema de decisión anterior es NP-Completo. Resolver las desigualdades anteriores es lo mismo que resolver el subset problem, que se demuestra que es NP-Completo. Por lo tanto, el problema de la mochila se puede reducir al problema de la suma de subconjuntos en tiempo polinomial.

Además, la complejidad de este problema depende del tamaño de los valores de entrada de v_i, w_i's. Es decir, si hay una forma de redondear los valores haciéndolos más restringidos, entonces tendríamos un algoritmo de tiempo polinomial.

Es decir, la parte no determinista del algoritmo radica en el tamaño de la entrada. Cuando las entradas son binarias, su complejidad se vuelve exponencial, lo que lo convierte en un problema NP-Completo.
*/