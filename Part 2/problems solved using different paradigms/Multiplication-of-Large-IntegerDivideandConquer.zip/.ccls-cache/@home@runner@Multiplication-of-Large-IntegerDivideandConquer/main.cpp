#include<cmath>
#include<iostream>

using namespace std;

unsigned long long noOfDigit(unsigned long long m,unsigned long long n)
{
    unsigned long long max;
    unsigned int b=0;
    if(m>=n)
        max=m;
    else
        max=n;
    while(max>0){
        max=max/10;
        b++;
    }
    return b;
}
unsigned long long prod(unsigned long long u,unsigned long long v){
    unsigned long long x,y,w,z;
    unsigned long long n,m,p,q,r;

    n = noOfDigit(u,v);

    if(u==0 || v==0)
        return 0;

    else if(n<=2)
        return (u*v);
    else{
        m=floor(n/2);

        w = u/pow(10,m);
        x = u % (int)pow(10,m);
        y = v/pow(10,m);
        z = v % (int)pow(10,m);

        p=prod(w,y);
        q=prod(x,z);
        r=prod(w+x,y+z);

        return p * pow(10,2*m) + (r-p-q) * pow(10,m) + q;
    }
}

int main()
{
    unsigned long long m=12345, n=76543;
    cout << prod(m,n);
}

/*
 comlexity analysis: O(log(n))    
    
 */