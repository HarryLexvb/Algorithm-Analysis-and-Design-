#include <iostream>
#include <numeric>
#include <unordered_map>
#include <string>
#include <utility>

using namespace std;

bool subsetSum(int S[], int n, int a, int b, int c, unordered_map<string, bool> lookup){
    if (a == 0 && b == 0 && c == 0)
        return true;
    if (n < 0)
        return false;
    string key = to_string(a) + "|" + to_string(b) + "|" + to_string(c) + "|" + to_string(n);

    if (lookup.find(key) == lookup.end()){
        bool A = false;
        if (a - S[n] >= 0)
            A = subsetSum(S, n - 1, a - S[n], b, c, lookup);
        bool B = false;
        if (!A && (b - S[n] >= 0))
            B = subsetSum(S, n - 1, a, b - S[n], c, lookup);
        bool C = false;
        if ((!A && !B) && (c - S[n] >= 0))
            C = subsetSum(S, n - 1, a, b, c - S[n], lookup);
        lookup[key] = A || B || C;
    }
    return lookup[key];
}

bool partition(int S[], int n){
    if (n < 3)
        return false;
    unordered_map<string, bool> lookup;
    int sum = accumulate(S, S + n, 0);
    return !(sum % 3) && subsetSum(S, n - 1, sum / 3, sum / 3, sum / 3, lookup);
}

int main(){

    int S[] = { 7, 3, 2,  5, 4, 8 };

    int n = sizeof(S) / sizeof(S[0]);

    if (partition(S, n))
        cout << "Yes";
    else
        cout << "No";

    return 0;
}

/*
 pasos para resolver el problema:
    1. crear una tabla de lookup para evitar la repeticion de calculos 
    2. en el caso de que se repita el mismo problema en el mismo recorrido de la tabla de lookup se retorna el valor de la tabla de lookup 
    3. si no se repite el mismo problema en el mismo recorrido de la tabla de lookup se calcula el valor del problema y se guarda en la tabla de lookup
    4. se retorna el valor de la tabla de lookup
    
 */