#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;
    

void print(vector<vector<char>> matrix){

    for_each(matrix.begin(), matrix.end(), [](const auto & n){
        for_each(n.begin(), n.end(), [](const auto & valor){
            if(valor == 0)
                cout << "." <<  "\t";//vacios
            else
                cout << "X" <<  "\t";//reinas
        });
        cout << endl;
    });
    cout << "\n\n";
}


bool check(vector<vector<char>> matrix, int r, int i, int N){
    for(int j = 0; j < N; ++j)
        if(matrix[j][i] == 1)//Barre verticales desde la posición [j][i] -> i = estático.
            return false;

    for(int j = 0; j < N; ++j)
        if(matrix[r][j] == 1)//Barre horizontales desde la posición [r][j] -> r = estático.
            return false;

    for(int j = 0; j < N; ++j)//Barre diagonales
        for(int k = 0; k < N; ++k)
            if (((matrix[j][k]) == 1) and ((j + k == r + i) or (j - k == r - i)))
                return false;

    return true;
}

void solve(vector<vector<char>> matrix, int r, int x, int y, int N ){
    if(r == N and matrix[x][y] == 1)
        print(matrix); // llega a su fin, se imprime la solución
 
    for(int i = 0; i < N; ++i){
        if(check(matrix, r, i, N) or (x == r and y == i)){
            //La segunda condición solo se cumple cuando se verifica la posición inicial dentro del bucle.
            //r avanza en cuanto a filas disponibles, i avanza en columnas.
            matrix[r][i] = 1;
            solve(matrix, r + 1, x, y, N);            
            if (x != r and y != i)
                matrix[r][i] = 0;
        }
    }
}

void Nqueen(int n, int x, int y){

    vector<vector<char>> matrix(n, vector<char>(n)); // se crea la matriz 
    matrix[x][y] = 1; //posicion inicial 
    solve(matrix, 0, x, y, n);
}

int main(){
    //nqueens_6(4, 2, 0);
    Nqueen(4, 2, 0);
}