#include <iostream>

using namespace std; 

int isTriangular(int** arr, int r, int c){
    int c1 =0,c2 = 0;
    for(int i =0; i < r; i++ ){
        for(int j =0; j < c; j++){
            if(i == j){
                if(*(*(arr+i)+j) == 0){
                    return 0;//false, ni es superio ni inferior
                    //la diagonal si o si debe tener numeros
                    //diferentes de cero
                }
            }
            if(j > i){
                if(*(*(arr+i)+j) != 0){
                    c1++;
                }
            }else if( j < i){
                if(*(*(arr+i)+j) != 0){
                    c2++;
                }
            }           
        }
    }
    if(c1 == 0){
        return -1;//matriz superior
    }else if(c2 == 0){
        return 1;//matriz inferior
    }else{
        return 0;//no es nada
    }
     
}
/*#include <iostream>
#include<string>

using namespace std;

int main(){
	int fila,columna;
	int Cantidad;
	cout << "Introduzca el tamaño de la matriz: ";
	cin >> Cantidad;
	
	fila = Cantidad;
	columna = Cantidad;
	
	//Creamos las matriz
	int A[fila][columna];
	string contenido = "";//concatenar la matriz para mostrar en orisontal
	int serie = 1;
	int filita = 0;
	int columnita = 0;
	while(filita < fila){
		while(columnita < columna){
		  if(columnita < filita){
		    A[filita][columnita] = 0;
		    contenido = contenido + to_string(A[filita][columnita]) + "   ";
		  }else{
		    A[filita][columnita] = serie;
		    contenido = contenido + to_string(A[filita][columnita]) + "   ";
			  serie++;
		  }
			columnita++;
		}
		contenido = contenido + "\n";
		filita++;
		columnita = 0;
	}
	cout << contenido << endl;	
  return 0;
}*/
int main() {

  int n = 5, arr[5][5], k=0; 
  for(int i = 1; i < n; ++i){
    for(int j = 1; j < n; ++j){
      if(i>j) arr[i][j]=0; 
      else arr[i][j] = k++; 
    }
    cout << endl; 
  }

  //mostrar 

  for(int i = 1; i < n; ++i){
    for(int j = 1; j < n; ++j){
      cout << arr[i][j] << "\t"; 
    }
    cout << endl; 
  }
  
}