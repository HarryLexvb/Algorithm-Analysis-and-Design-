#include<iostream>

using namespace std ;

#define V 4

void print(int *color){
    cout << "YES\n";
    for (int i = 0; i < V; ++i)
        cout << "  " << color[i];
    cout << "\n";
}
bool isSafe(bool graph[V][V], int *color){
    for (int i = 0; i < V; ++i)
        for (int j = i + 1; j < V; ++j)
            if (graph[i][j] && color[j] == color[i])
                return false;
    return true;
}
bool coloring(bool graph[V][V], int m, int i, int color[V]){
    if (i == V) {
        if (isSafe(graph, color)) {
            print(color);
            return true;
        }
        return false;
    }
    for (int j = 1; j <= m; ++j) {
        color[i] = j;
        if (coloring(graph, m, i + 1, color))
            return true;
        color[i] = 0;
    }
    return false;
}

int main(){

    bool graph[V][V] = {
            { 0, 1, 1, 1 },
            { 1, 0, 1, 0 },
            { 1, 1, 0, 1 },
            { 1, 0, 1, 0 },
    };
    int m = 3;

    int color[V];
    for (int i = 0; i < V; i++)
        color[i] = 0;

    if (!coloring(graph, m, 0, color))
        cout << "NO";

    return 0;
}

/*
Complejidad temporal: O(m^V). Hay una combinación total de colores O(m^V). Entonces la complejidad del tiempo es O(m^V).

Generar todas las configuraciones posibles de colores. Dado que cada nodo se puede colorear con cualquiera de los m colores disponibles, el número total de configuraciones
 de color posibles es m^V. Después de generar una configuración de color, comprueba si los vértices adyacentes tienen el mismo color o no. Si se cumplen las condiciones,
 imprima la combinación y rompa el bucle.

 1 Cree una función recursiva que tome el índice actual, el número de vértices y la matriz de colores de salida.
 2 Si el índice actual es igual al número de vértices. Compruebe si la configuración del color de salida es segura, es decir, compruebe si los
 vértices adyacentes no tienen el mismo color. Si se cumplen las condiciones, imprima la configuración y rompa.
 3 Asigne un color a un vértice (1 a m).
 4 Para cada color asignado, llame recursivamente a la función con el siguiente índice y número de vértices
 5 Si alguna función recursiva devuelve verdadero, rompe el bucle y devuelve verdadero.
 */  