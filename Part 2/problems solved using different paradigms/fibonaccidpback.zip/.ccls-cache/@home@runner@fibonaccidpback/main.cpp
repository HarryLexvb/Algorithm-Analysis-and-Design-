#include <iostream>
using namespace std;

int fibonacci(int n){ //O(e^n)
    if(n < 2)
        return n;
    else
        return fibonacci(n-1)+fibonacci(n-2);
}

int fibonacci_dp_topdown(int n, int *dp){ //O(n) dp usando estrategia de top down
    if(dp[n] == 0)
        dp[n] = fibonacci_dp_topdown(n-1, dp)+fibonacci_dp_topdown(n-2, dp);
    return dp[n];
}

int F[50];
int fibonacci_dp_bottonup(int n){
    F[n] = 0;
    F[1] = 1;

    int i;
    for(i=2; i<=n; i++) {
        F[i] = F[i-1] + F[i-2];
    }
    return F[n];
}


int main(){
    {
        cout << "fibonacci: " << endl;
        cout << fibonacci(7) << endl;
    }

    {
        cout << "fibonacci_dp_topdown: " << endl;
        int n = 7, *arr;
        arr = new int(n);
        arr[0] = 1;
        arr[1] = 1;
        for (int i = 2; i < n; ++i)
            arr[i] = 0;
        cout << fibonacci_dp_topdown(n - 1, arr) << endl;
    }
    {
        cout << "fibonacci_dp_bottonup: " << endl;
        cout << fibonacci_dp_bottonup(7) << endl;
    }

}