#include<iostream>
#include<ctime>
using namespace std;

class quick_sort
{
private:
    int n,z;
    int *A;
public:
    static void swap(int* a, int* b);
    void accept();
    void print(int *arr);
    void quicksort(int *arr, int low, int high);
    static int partition(int *arr, int low, int high);
};

void quick_sort::swap(int* a, int* b){
    int t = *a;
    *a = *b;
    *b = t;
}

void quick_sort::accept(){
    cout<<"\nSize: "; cin>>n;
    A = new int[n];
    srand(time(nullptr));
    for(int i=0;i<n;i++)
        A[i] = rand()%100+1;

    cout<<"\nOriginal: \n";
    print(A);
    quicksort(A,0,n-1);
    cout<<"\nOrdenado: \n";
    print(A);
}

void quick_sort::print(int *arr){
    for(z=0;z<n;z++)
        cout<<A[z]<<"\t";
    cout<<endl;
}

void quick_sort::quicksort(int *arr, int low, int high){
    if (low < high){
        int pi = partition(arr, low, high);
        quicksort(arr, low, pi - 1);
        quicksort(arr, pi + 1, high);
    }
}

int quick_sort::partition(int *arr, int low, int high)
{
    int pivot = arr[high];
    int i = (low - 1);

    for (int j = low; j <= high - 1; j++){
        if (arr[j] < pivot){
            ++i;
            swap(&arr[i], &arr[j]);
        }
    }
    swap(&arr[i + 1], &arr[high]);
    return (i + 1);
}

int main(){
    quick_sort q{};
    q.accept();
}

/*
 1. del vectr original se selecciona el pivote
 2. Divide los elementos restantes en particiones izquierda y derecha, de modo que ningún elemento de la izquierda tenga una clave mayor que el pivote
 y que ningún elemento de la derecha tenga una clave mas pequeña que la del pivote.
 3 Ordena la partición izquierda utilizando quicksort recursivamente.
 4 Ordena la partición derecha utilizando quicksort recursivamente.
 5 La solución es la partición izquierda seguida por el pivote y a continuación la partición derecha.
    
    T(n) = 2T(n/2) + Cn
    O(nlogn)
 */