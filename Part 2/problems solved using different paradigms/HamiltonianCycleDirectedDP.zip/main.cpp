#include<iostream>
#include <list>
#include <vector>
#include <cstring>

//ciclo hamiltoniano grafo no dirigido  usando dp

using namespace std;
const int N = 5;

bool Hamiltonian_path_dp(vector<vector<int> >& adj, int N){
    int dp[N][(1 << N)];
    memset(dp, 0, sizeof dp);
    for (int i = 0; i < N; i++)
        dp[i][(1 << i)] = true;
    for (int i = 0; i < (1 << N); i++) {
        for (int j = 0; j < N; j++) {
            if (i & (1 << j)) {
                for (int k = 0; k < N; k++) {
                    if (i & (1 << k) and adj[k][j] and j != k
                        && dp[k][i ^ (1 << j)]) {
                        dp[j][i] = true;
                        break;
                    }
                }
            }
        }
    }
    for (int i = 0; i < N; i++) {
        if (dp[i][(1 << N) - 1])
            return true;
    }
    return false;
}

int main(){

    vector<vector<int> > adj = { { 0, 1, 1, 1, 0 },
                                 { 1, 0, 1, 0, 1 },
                                 { 1, 1, 0, 1, 1 },
                                 { 1, 0, 1, 0, 0 } };
    int N = adj.size();

    if (Hamiltonian_path_dp(adj, N))
        cout << "YES";
    else
        cout << "NO";

    return 0;
}
//O(N * 2^N)
/*
 1 Inicialice una matriz booleana dp[][] en la dimensión N*2^N donde dp[j ][i] representa si existe o no un camino en el subconjunto representado por la máscara i
 que visita todos y cada uno de los vértices en i una vez y termina en vértice j.
 2 Para el caso base, actualice dp [i] [1 << i] = verdadero, para i en el rango [0, N - 1]
 3 Para el caso recursivo, para cada i en el rango [0, N - 1]
 4 Iterar sobre el rango [1, 2^N – 1] usando la variable i
 5 Itere sobre el rango usando la variable i y si el valor de dp[i][2N – 1] es verdadero, entonces existe un camino hamiltoniano que termina en el vértice i.
 Por lo tanto, imprima "YES". De lo contrario, escriba “No”.
 */