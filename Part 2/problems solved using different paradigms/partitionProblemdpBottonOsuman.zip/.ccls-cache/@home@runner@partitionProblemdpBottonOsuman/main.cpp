#include <iostream>

using namespace std;

bool findPartiion_dp_botton(const int *arr, int n){
    int sum = 0;
    int i, j;
    for (i = 0; i < n; i++)
        sum += arr[i];
    if (sum % 2 != 0)
        return false;
    bool part[sum / 2 + 1][n + 1];
    for (i = 0; i <= n; i++)
        part[0][i] = true;
    for (i = 1; i <= sum / 2; i++)
        part[i][0] = false;
    for (i = 1; i <= sum / 2; i++) {
        for (j = 1; j <= n; j++) {
            part[i][j] = part[i][j - 1];
            if (i >= arr[j - 1])
                part[i][j] = part[i][j]
                             || part[i - arr[j - 1]][j - 1];
        }
    }
    return part[sum / 2][n];
}

int main()
{
    {
        int arr[] = {3, 1, 5, 9, 12};
        int n = sizeof(arr) / sizeof(arr[0]);

        // Function call
        if (findPartiion_dp_botton(arr, n))
            cout << "YES" << endl; // si es posible dividir la matriz en dos subset con igual suma
        else
            cout << "NO" << endl; // no es posible dividir la matriz en dos subset con igual suma

    }

    {
        int arr[] = {3, 1, 5, 9, 14};
        int n = sizeof(arr) / sizeof(arr[0]);

        if (findPartiion_dp_botton(arr, n))
            cout << "YES" << endl; // si es posible dividir la matriz en dos subset con igual suma
        else
            cout << "NO" << endl; // no es posible dividir la matriz en dos subset con igual suma
    }
}

/*
 El problema se puede resolver mediante programación dinámica cuando la suma de los elementos no es demasiado grande. Podemos crear una matriz
 2D part[][] de tamaño (sum/2 + 1)*(n+1). Y podemos construir la solución de forma ascendente de modo que cada entrada completa tenga la siguiente propiedad

 parte [i] [j] = verdadero si un subconjunto de {arr [0], arr [1], ..arr [j-1]} tiene suma igual a i, de lo contrario falso


 Complejidad del tiempo: O(suma*n)

 */