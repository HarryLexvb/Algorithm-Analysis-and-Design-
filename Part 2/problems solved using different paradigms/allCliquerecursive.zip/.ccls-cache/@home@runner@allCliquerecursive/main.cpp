#include <iostream>

using namespace std;

const int MAX = 100;
int store[MAX], n;
int graph[MAX][MAX];
int d[MAX];

bool is_clique(int b){
    for (int i = 1; i < b; ++i) {
        for (int j = i + 1; j < b; j++)
            if (graph[store[i]][store[j]] == 0)
                return false;
    }
    return true;
}

void print(int n){
    for (int i = 1; i < n; ++i)
        cout << store[i] << " ";
    cout << ", ";
}

void find_Cliques(int i, int l, int s){
    for (int j = i + 1; j <= n - (s - l); j++)
        if (d[j] >= s - 1) {
            store[l] = j;
            if (is_clique(l + 1))
                if (l < s)
                    find_Cliques(j, l + 1, s);
                else
                    print(l + 1);
        }
}

int main()
{
    int edges[][2] = { { 1, 2 },
                       { 2, 3 },
                       { 3, 1 },
                       { 4, 3 },
                       { 4, 5 },
                       { 5, 3 } },
            k = 3;
    int size = sizeof(edges) / sizeof(edges[0]);
    n = 5;

    for (int i = 0; i < size; i++) {
        graph[edges[i][0]][edges[i][1]] = 1;
        graph[edges[i][1]][edges[i][0]] = 1;
        d[edges[i][0]]++;
        d[edges[i][1]]++;
    }

    find_Cliques(0, 1, k);
}

/*
 Se encuentran todos los vértices cuyo grado es mayor o igual a (K-1) y se comprueba qué subconjunto de K vértices forman un Clique. Cuando se
 agrega otra arista a la lista actual, se verifica si al agregar esa arista, la lista todavía forma un clique o no.

 pasos:
 1 Se orma una función recursiva con tres parámetros nodo inicial, longitud del conjunto actual de nodos y longitud deseada de nodos.
 2 Se ejecuta un bucle desde ese índice hasta n.
 3 Si se encuentra que después de agregar un nodo al conjunto actual, el conjunto de nodos sigue siendo un clique. Si es asi, se agrega ese nodo
    y se llama a la función recursiva con el índice de parámetros del nuevo nodo agregado +1, la longitud del conjunto actual + 1 y la longitud deseada.
 4 Si se alcanza la longitud deseada, se imprimen los nodos.
 */