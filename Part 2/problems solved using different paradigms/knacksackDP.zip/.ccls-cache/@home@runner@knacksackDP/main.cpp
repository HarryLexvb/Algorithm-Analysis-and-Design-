#include <iostream>
#include <vector>
using namespace std;
/*
 Complejidad temporal: O(N*W)
 N: número de elementos de peso
 W: es la capacidad. Por ejemplo, si W=10, entonces el peso máximo es 10.
 */

int knapSack_dp(int W, int *wt, int *value, int n){ //usando botton up
    vector<vector<int>> vec(n + 1, vector<int>(W + 1));
    for(int i = 0; i <= n; ++i){
        for(int j = 0; j <= W; ++j){
            if (i == 0 or j == 0)
                vec[i][j] = 0;
            else if (wt[i - 1] <= j)
                vec[i][j] = max(value[i - 1] + vec[i - 1][j - wt[i - 1]], vec[i - 1][j]);
            else
                vec[i][j] = vec[i - 1][j];
        }
    }
    return vec[n][W];
}

int main(){
    int val[] = { 50, 90, 110 };
    int wt[] = { 20, 30, 40 };
    int W = 60;
    int n = sizeof(val) / sizeof(val[0]);
    cout << knapSack_dp(W, wt, val, n);
}

/*
Dados los pesos y valores de los elementos, w y v, respectivamente, ¿se puede elegir un subconjunto de elementos x subconjunto propio {1,2,...n} que satisfagan las siguientes restricciones?

Una solución de 'Sí' o 'No' al problema de decisión anterior es NP-Completo. Resolver las desigualdades anteriores es lo mismo que resolver el subset problem, que se demuestra que es NP-Completo. Por lo tanto, el problema de la mochila se puede reducir al problema de la suma de subconjuntos en tiempo polinomial.

Además, la complejidad de este problema depende del tamaño de los valores de entrada de v_i, w_i's. Es decir, si hay una forma de redondear los valores haciéndolos más restringidos, entonces tendríamos un algoritmo de tiempo polinomial.

Es decir, la parte no determinista del algoritmo radica en el tamaño de la entrada. Cuando las entradas son binarias, su complejidad se vuelve exponencial, lo que lo convierte en un problema NP-Completo.
*/