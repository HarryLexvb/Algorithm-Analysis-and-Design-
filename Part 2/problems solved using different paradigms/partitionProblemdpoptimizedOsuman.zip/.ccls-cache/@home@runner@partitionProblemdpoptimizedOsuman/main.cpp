#include <iostream>
#include <vector>

using namespace std;


bool findPartiion_dp_optimized(int arr[], int n){
    int sum = 0;
    int i, j;
    for (i = 0; i < n; i++)
        sum += arr[i];

    if (sum % 2 != 0)
        return false;

    bool part[sum / 2 + 1];

    for (i = 0; i <= sum / 2; i++)
        part[i] = 0;

    for (i = 0; i < n; i++) {
        for (j = sum / 2; j >= arr[i]; j--) {
            if (part[j - arr[i]] == 1 || j == arr[i])
                part[j] = 1;
        }
    }
    return part[sum / 2];
}


int main()
{
    {
        int arr[] = {3, 1, 5, 9, 12};
        int n = sizeof(arr) / sizeof(arr[0]);

        // Function call
        if (findPartiion_dp_optimized(arr, n))
            cout << "YES" << endl; // si es posible dividir la matriz en dos subset con igual suma
        else
            cout << "NO" << endl; // no es posible dividir la matriz en dos subset con igual suma

    }

    {
        int arr[] = {3, 1, 5, 9, 14};
        int n = sizeof(arr) / sizeof(arr[0]);

        if (findPartiion_dp_optimized(arr, n))
            cout << "YES" << endl; // si es posible dividir la matriz en dos subset con igual suma
        else
            cout << "NO" << endl; // no es posible dividir la matriz en dos subset con igual suma
    }
}

/*
 En lugar de crear una matriz 2-D de tamaño (sum/2 + 1)*(n  + 1), podemos resolver este problema utilizando únicamente una matriz de
 tamaño (sum/2 + 1). parte[j] = verdadero si hay un subconjunto con suma igual a j, de lo contrario falso.
 Complejidad temporal: O(suma * n)

 pasos para resolver findPartiion_dp_optimized:
    1. Inicializar la matriz de tamaño (sum/2 + 1) con todos los valores falsos.
    2. Para cada elemento de la matriz, verificar si el elemento es igual a la suma de los elementos de la matriz.
    3. Si el elemento es igual a la suma de los elementos de la matriz, entonces el elemento es verdadero.
    4. Si el elemento es mayor a la suma de los elementos de la matriz, entonces el elemento es falso.

 */