#include <iostream>
#include <map>
#include <list>

using namespace std;

template <typename T>
class Graph
{
private:
    map<T, list<T>> l;

public:
    void addEdge(T x, T y){
        l[x].push_back(y);
        l[y].push_back(x);
    }

    void dfs_helper(T src, map<T, bool> &visited){

        cout << src << " ";
        visited[src] = true;
        for (T nbr : l[src]){
            if (!visited[nbr])
                dfs_helper(nbr, visited);

        }
    }

    void dfs(T src){
        cout << "DFS: ";
        map<T, bool> visited;

        for ([[maybe_unused]] const auto& node : l)
            visited[node.first] = false;
        dfs_helper(src, visited);
    }

    void print(){
        for ([[maybe_unused]] const auto& node : l)
        {
            cout << node.first << " -> ";
            for (T nbr : node.second)
                cout << nbr << " ";
            cout << endl;
        }
    }
};

int main()
{
    Graph<int> g;
    g.addEdge(0, 1);
    g.addEdge(1, 2);
    g.addEdge(2, 3);
    g.addEdge(3, 4);
    g.addEdge(4, 5);
    g.addEdge(0, 3);
    g.print();
    g.dfs(0);
}

/*

    1. Inicializar una lista de visitados
    2. Inicializar una lista de nodos a visitar
    3. Mientras la lista de nodos a visitar no esté vacía
        3.1. Sacar el primer nodo de la lista de nodos a visitar
        3.2. Si el nodo no ha sido visitado
            3.2.1. Imprimir el nodo
            3.2.2. Agregar el nodo a la lista de visitados
            3.2.3. Para cada nodo adyacente
    4 . Imprimir la lista de visitados

    complexity: O(V+E)
*/