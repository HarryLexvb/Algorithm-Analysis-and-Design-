#include <iostream>
#include <vector>
using namespace std;

int dictionary(string word)
{
    string dictionary[] = { "mobile", "samsung", "sam",
                            "sung", "man", "mango",
                            "icecream", "and", "go",
                            "i", "like", "ice", "cream" };
    int size = sizeof(dictionary) / sizeof(dictionary[0]);
    for (int i = 0; i < size; i++)
        if (dictionary[i].compare(word) == 0)
            return 1;
    return 0;
}

int main()
{
    string s = "ilikesamsung";
    int n = s.size();
    bool res;
    if (n == 0)
        return true;
    vector<bool> dp(n + 1, 0);
    vector<int> matched_index;
    matched_index.push_back(-1);
    for (int i = 0; i < n; i++) {
        int msize = matched_index.size();
        int f = 0;
        for (int j = msize - 1; j >= 0; j--) {
            string sb = s.substr(matched_index[j] + 1, i - matched_index[j]);

            if (dictionary(sb)) {
                f = 1;
                break;
            }
        }

        if (f == 1) {
            dp[i] = 1;
            matched_index.push_back(i);
        }
    }
    res = dp[n - 1];
    cout << res;
    return 0;
}

/*
pasos para resolver el problema:
1. crear un vector de booleanos de tamaño n+1 (para el caso base) y llenarlo con 0 (no hay palabra) para todos los indices del vector
 2. darle un valor 1 a la posicion de la ultima letra de la palabra (para el caso base) para que se pueda comparar con el vector de booleanos de tamaño n+1
 3. dicho vector de booleanos se llena con un valor 1 si la palabra que se esta comparando es una palabra del diccionario
 */