#include<iostream>

using namespace std;

#define V 4

void printSolution(int *color){
    cout << "YES\n";
    for(int i = 0; i < V; ++i)
        cout << " " << color[i] << " ";
    cout << "\n";
}

bool isSafe(int v, bool graph[V][V], const int *color, int c){
    for(int i = 0; i < V; ++i)
        if (graph[v][i] && c == color[i])
            return false;

    return true;
}
bool graphColoringUtil(bool graph[V][V], int m, int *color, int v){
    if (v == V)
        return true;
    for(int c = 1; c <= m; ++c){
        if (isSafe(v, graph, color, c)){
            color[v] = c;
            if (graphColoringUtil(graph, m, color, v + 1))
                return true;
            color[v] = 0;
        }
    }
    return false;
}

bool coloring(bool graph[V][V], int m){
    int color[V];
    for(int & i : color)
        i = 0;
    if (!graphColoringUtil(graph, m, color, 0)){
        cout << "NO";
        return false;
    }
    printSolution(color);
    return true;
}

int main(){
    bool graph[V][V] = { { 0, 1, 1, 1 },
                         { 1, 0, 1, 0 },
                         { 1, 1, 0, 1 },
                         { 1, 0, 1, 0 }, };

    int m = 3;
    coloring(graph, m);
    return 0;
}

/*
Complejidad temporal: O(m^V). Hay una combinación total de colores O(m^V). Entonces la complejidad del tiempo es O(m^V). La complejidad del tiempo de límite superior
 sigue siendo la misma, pero el tiempo medio necesario será menor.

La idea es asignar colores uno por uno a diferentes vértices, comenzando desde el vértice 0. Antes de asignar un color, verifique la seguridad considerando los
 colores ya asignados a los vértices adyacentes, es decir, verifique si los vértices adyacentes tienen el mismo color o no. Si hay alguna asignación de color que no
 viole las condiciones, marque la asignación de color como parte de la solución. Si no es posible asignar un color, retroceda y devuelva falso.

 1 Cree una función recursiva que tome el gráfico, el índice actual, el número de vértices y la matriz de colores de salida.
 2 Si el índice actual es igual al número de vértices. Imprima la configuración de color en la matriz de salida.
 3 Asigne un color a un vértice (1 a m).
 4 Para cada color asignado, verifique si la configuración es segura (es decir, verifique si los vértices adyacentes no tienen el mismo color)
 llame recursivamente a la función con el siguiente índice y número de vértices
 5 Si alguna función recursiva devuelve verdadero, rompa el ciclo y devuelva verdadero.
 6 Si ninguna función recursiva devuelve verdadero, devuelve falso.
 */