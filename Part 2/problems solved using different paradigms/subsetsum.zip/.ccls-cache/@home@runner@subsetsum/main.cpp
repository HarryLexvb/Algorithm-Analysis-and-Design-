#include <iostream>
#include <numeric>

bool subsetSum(int S[], int n, int a, int b, int c, int arr[]){
    if (a == 0 && b == 0 && c == 0)
        return true;
    if (n < 0)
        return false;
    bool A = false;
    if (a - S[n] >= 0){
        arr[n] = 1;		
        A = subsetSum(S, n - 1, a - S[n], b, c, arr);
    }
    bool B = false;
    if (!A && (b - S[n] >= 0)){
        arr[n] = 2;		
        B = subsetSum(S, n - 1, a, b - S[n], c, arr);
    }
    bool C = false;
    if ((!A && !B) && (c - S[n] >= 0)){
        arr[n] = 3;		
        C = subsetSum(S, n - 1, a, b, c - S[n], arr);
    }

    return A || B || C;
}

void partition(int S[], int n){
  
    int sum = std::accumulate(S, S + n, 0);
    int arr[7];
    bool res = (n >= 3) && !(sum % 3) &&
               subsetSum(S, n - 1, sum / 3, sum / 3, sum / 3, arr);

    if (!res)
    {
        std::cout << "3-Partition of set is not Possible";
        return;
    }

    for (int i = 0; i < 3; i++)
    {
        std::cout << "Partition " << i << " is: ";
        for (int j = 0; j < n; j++)
            if (arr[j] == i + 1)
                std::cout << S[j] << " ";
        std::cout << std::endl;
    }
}
int main(){
    int S[] = { 7, 3, 2,  5, 4, 8 };
    int n = sizeof(S) / sizeof(S[0]);

    partition(S, n);

    return 0;
}

/*
 pasos para resolver el problema:
    1. verificar que el numero de elementos sea mayor a 3 y que el suma de los elementos sea divisible entre 3 (para que sea posible dividir el conjunto en 3 partes)
    2. llamar a la funcion subsetSum que recibe como parametros el conjunto, el numero de elementos, el numero de elementos que se quiere que sean de la primera parte,
    el numero de elementos que se quiere que sean de la segunda parte y el numero de elementos que se quiere que sean de la tercera parte
    3. si la funcion retorna true, entonces se puede dividir el conjunto en 3 partes, si no, no se puede dividir en 3 partes y se imprime un mensaje de error
    4. imprimir los elementos de cada parte



Reducción de 3-Sat a Subset Sum: 
- n variables xi y m cláusulas cj 
- Para cada variable xi , construya números ti y fi de n + m dígitos:     - El i-ésimo dígito de ti y fi es igual a 1 
  - Para n + 1 ≤ j ≤ n + m, el j-ésimo dígito de ti es igual a 1 si xi      está en la cláusula cj−n
  - Para n + 1 ≤ j ≤ n + m, el j-ésimo dígito de fi es igual a 1 si ~xi      es en la cláusula cj−n 
- Todos los demás dígitos de ti y fi son 0

Para cada cláusula cj , construya números xj e yj de n + m dígitos: 
  - El (n + j)-ésimo dígito de xj e yj es igual a 1 
  - Todos los demás dígitos de xi e yj son 0

Finalmente, construya un número de suma s de n + m dígitos: 
  - Para 1 ≤ j ≤ n, el j-ésimo dígito de s es igual a 1
  - Para n + 1 ≤ j ≤ n + m, el j-ésimo dígito de s es igual a 3

Demuestre que la fórmula es satisfactoria ⇒ Existe un subconjunto: 
  - tome ti si xi es verdadero 
  - Tome fi si xi es falso 
  - Tome xj si el número de literales verdaderos en cj es como máximo 2   - Tome yj si el número de literales verdaderos en cj es 1

Demostrar que el subconjunto existe ⇒ Fórmula satisfactoria: 
  - Asignar valor verdadero a xi si ti está en el subconjunto 
  - Asignar valor falso a xi si fi está en el subconjunto 
  - Exactamente un número por variable debe estar en el subconjunto
    - De lo contrario, uno de los primeros n dígitos de la suma es            mayor que 1 
  - La asignación es consistente 
  - Al menos un número de variable correspondiente a un literal en una      cláusula debe estar en el subconjunto 
    - De lo contrario, uno de los siguientes m dígitos de la suma es          menor que 3 
  - Cada cláusula se cumple

por lo tanto subsetsum es np completo
    
 */