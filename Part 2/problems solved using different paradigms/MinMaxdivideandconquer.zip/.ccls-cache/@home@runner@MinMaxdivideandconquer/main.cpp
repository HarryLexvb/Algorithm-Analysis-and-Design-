#include<iostream>
using namespace std;

class minmax
{
private:
    int n, min, max;
    int *a;
public:
    void accept();
    void maxmin(int i, int j);
    void print();
};

void minmax::accept(){

    /*cout<<"\nEnter the number of elements : "; cin>>n;
    cout<<"\nEnter the elements : \n";
    for(int i=0;i<n;i++)
        cin>>a[i];*/

    cout << "size: "; cin >> n;
    a = new int[n];
    for (int i = 0; i < n; i++)
        a[i] = rand() % 100 + 1;

    cout<<"\narray: \n";
    print();
    max = a[0];
    min = a[0];
    maxmin(1, n-1);
    cout<<"\nminimo: "<<min;
    cout<<"\nmaximo: "<<max;
}

void minmax::maxmin(int i, int j){
    int max1, min1, mid;
    if(i==j)
        max = min = a[i];
    else{
        if(i == j-1){
            if(a[i] < a[j]){
                max = a[j];
                min = a[i];
            }
            else{
                max = a[i];
                min = a[j];
            }
        }
        else{
            mid = (i+j)/2;
            maxmin(i, mid);
            max1 = max;
            min1 = min;
            maxmin(mid+1, j);
            if(max < max1)
                max = max1;
            if(min > min1)
                min = min1;
        }
    }
}

void minmax::print(){
    for(int i = 0; i < n; ++i)
        cout<<a[i]<<"\t";
}

int main(){
    minmax m{};
    m.accept();
}