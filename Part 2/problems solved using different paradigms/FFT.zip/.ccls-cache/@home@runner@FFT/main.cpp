#include <iostream>
#include <complex>
#include <cmath>
#include <valarray>

using namespace std;

#define PI 3.14159265358979323846
typedef complex<double> x_n;
typedef valarray<x_n> arr;

void FFT_t(arr &v){
    int n = v.size();
    if(n > 1) {
        arr odd(n / 2);
        arr even(n / 2);
        for (int i = 0; 2 * i < n; ++i) {
            even[i] = v[2 * i];
            odd[i] = v[2 * i + 1];
        }
        FFT_t(even);
        FFT_t(odd);
        double ang = -2 * PI / n;
        x_n w(1.0);
        x_n wn(cos(ang), sin(ang));
        for (int k = 0; k < n / 2; ++k) {
            v[k] = even[k] + w * odd[k];
            v[k + n / 2] = even[k] - w * odd[k];
            w *= wn;
        }
    }
}

void IFFT_f(arr &v){
    v = v.apply(conj);
    FFT_t(v);
    v = v.apply(conj);
    v /= v.size();
}

void IFFT_f2 ( arr & v ) {
    int n = v . size () ;
    if( n > 1) {
        arr odd ( n / 2) ;
        arr even ( n / 2) ;
        for (int i = 0; 2 * i < n ; ++ i ) {
            even [ i ] = v [2 * i ];
            odd [ i ] = v [2 * i + 1];
        }
        IFFT_f2 ( even ) ;
        IFFT_f2 ( odd ) ;
        double ang = 2 * PI / n ;
        x_n w (1.0) ;
        x_n wn ( cos ( ang ) , sin ( ang ) ) ;
        for (int k = 0; k < n / 2; ++ k ) {
            v[k] = even[k] + w * odd[k];
            v[k + n / 2] = even[k] - w * odd[k];
            w *= wn;
        }
    }

}

int get_size(const int *X){
    return sizeof(X)/((sizeof(*X))/2);
}

int main(){
    //x_n v[] = {-4, -4, -12, -16}; //{-36,8-12i,4,8+12i};
    x_n v[] = {1,2,0,-1}; //{2,1-3i,0,1+3i};
    int size = 4;
    arr data(v, size);
    FFT_t(data);
    std::cout << "FFT_t" << std::endl;
    for (int i = 0; i < size; ++i)
        std::cout << data[i] << std::endl;

    IFFT_f(data);
    std::cout << std::endl << "IFFT_f" << std::endl;
    for (int i = 0; i < size; ++i)
        std::cout << data[i] << std::endl;

    /*IFFT_f2(data);
    std::cout << std::endl << "IFFT_f2" << std::endl;
    for (int i = 0; i < size; ++i)
        std::cout << data[i] << std::endl;*/
}

/*
 pasos de la transformada de Fourier:
    1. dividir el vector en dos vectores de la misma longitud
    2. llamar a la transformada de Fourier de cada vector
    3. sumar los vectores de la transformada de Fourier de los dos vectores
    4. dividir por la longitud del vector
    
    pasos de la inversa de la transformada de Fourier:
    1. dividir el vector en dos vectores de la misma longitud
    2. llamar a la inversa de la transformada de Fourier de cada vector
    3. sumar los vectores de la inversa de la transformada de Fourier de los dos vectores
    4. dividir por la longitud del vector
    
    complejidad de la transformada rapida de Fourier:
    O(nlog(n))
    
 */