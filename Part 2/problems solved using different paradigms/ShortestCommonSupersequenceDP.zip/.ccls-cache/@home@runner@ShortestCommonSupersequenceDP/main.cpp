#include <iostream>
#include <string>
#include <algorithm>

using namespace std;


string printSSS(string X, string Y){
    int x = X.length();
    int y = Y.length();

    int dp[x + 1][y + 1];

    for (int i = 0; i <= x; i++){
        for (int j = 0; j <= y; j++){
            (!i) ? dp[i][j] = j : (!j) ? dp[i][j] = i : (X[i - 1] == Y[j - 1]) ? dp[i][j] = 1 + dp[i - 1][j - 1] : dp[i][j] = 1 + min(dp[i - 1][j], dp[i][j - 1]);

        }
    }

    int index = dp[x][y];

    string str;

    int i = x, j = y;
    while (i > 0 && j > 0){
        if (X[i - 1] == Y[j - 1]){
            str.push_back(X[i - 1]);
            i--, j--, index--;
        }

        else if (dp[i - 1][j] > dp[i][j - 1]){
            str.push_back(Y[j - 1]);
            j--, index--;
        }
        else{
            str.push_back(X[i - 1]);
            i--, index--;
        }
    }
    for(;i>0;i-- and index--)
        str.push_back(X[i - 1]);

    for (; j > 0; j-- and index--)
        str.push_back(Y[j - 1]);

    reverse(str.begin(), str.end());
    return str;
}

int main()
{
    string X = "AGGTAB";
    string Y = "GXTXAYB";

    cout << printSSS(X, Y);

    return 0;
}

/*
 pasos para resolver el problema:
    1. crear una matriz de tamaño (X.length() + 1) x (Y.length() + 1)
    2. llenar la matriz con ceros
    3. llenar la matriz con los valores de la matriz anterior
    4. imprimir la matriz
    5. imprimir la matriz en forma de string
    6. imprimir la matriz en forma de string con el algoritmo de la matriz anterior

 */