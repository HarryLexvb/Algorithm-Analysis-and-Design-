  #include <iostream>

using namespace std;

const int MAX = 100;

int store[MAX], n;
int graph[MAX][MAX];
int d[MAX];

bool is_clique(int b){
    for (int i = 1; i < b; i++) {
        for (int j = i + 1; j < b; j++)
            if (graph[store[i]][store[j]] == 0)
                return false;
    }
    return true;
}

int max_Clique(int i, int l){
    int maximo = 0;
    for (int j = i + 1; j <= n; j++) {
        store[l] = j;
        if (is_clique(l + 1)) {
            maximo = max(maximo, l);
            maximo = max(maximo, max_Clique(j, l + 1));
        }
    }
    return maximo;
}

int main()
{
    int edges[][2] = { { 1, 2 }, { 2, 3 }, { 3, 1 },
                       { 4, 3 }, { 4, 1 }, { 4, 2 } };
    int size = sizeof(edges) / sizeof(edges[0]);
    n = 4;

    for (int i = 0; i < size; i++) {
        graph[edges[i][0]][edges[i][1]] = 1;
        graph[edges[i][1]][edges[i][0]] = 1;
        d[edges[i][0]]++;
        d[edges[i][1]]++;
    }
    cout << max_Clique(0, 1);
}

/*Cuando se agrega una arista a la lista actual, se verifica si al agregar esa arista aun forma un clique  o no.
Los vértices se suman hasta que la lista no forma un clique. Luego, la lista se retrocede para encontrar un subconjunto más grande que forma un clique.*/