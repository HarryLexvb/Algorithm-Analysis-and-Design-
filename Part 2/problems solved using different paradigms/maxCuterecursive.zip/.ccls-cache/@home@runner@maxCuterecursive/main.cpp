#include<iostream>
#include <list>

using namespace std;

#define N -1

class G {

    int n;
    list<int> *adj;
    void connections(int n, bool visited[], int disc[], int low[], int par[]);
public:
    G(int n);
    void addEdge(int w, int x);
    void Connected_Components();
};
G::G(int n) {
    this->n= n;
    adj = new list<int> [n];
}

void G::addEdge(int w, int x) {
    adj[x].push_back(w);
    adj[w].push_back(x);
}
void G::connections(int w, bool *visited, int *dis, int *low, int *par) {
    static int t = 0;
    visited[w] = true;
    dis[w] = low[w] = ++t;
    list<int>::iterator i;
    for (i = adj[w].begin(); i != adj[w].end(); ++i) {
        int x = *i;
        if (!visited[x]) {
            par[x] = w;
            connections(x, visited, dis, low, par);
            low[w] = min(low[w], low[x]);
            if (low[x] > dis[w])
                cout << w << " " << x << endl;
        }
        else if (x != par[w])
            low[w] = min(low[w], dis[x]);
    }
}
void G::Connected_Components() {
    bool *visited = new bool[n];
    int *dis = new int[n];
    int *low = new int[n];
    int *par = new int[n];
    for (int i = 0; i < n; i++) {
        par[i] = N;
        visited[i] = false;
    }
    for (int i = 0; i < n; i++)
        if (visited[i] == false)
            connections(i, visited, dis, low, par);
}
int main() {

    G g1(5);
    g1.addEdge(1, 2);
    g1.addEdge(3, 2);
    g1.addEdge(2, 1);
    g1.addEdge(0, 1);
    g1.addEdge(1, 4);
    g1.Connected_Components();
}

/*
 funcion connections
 A) Marque el nodo actual como no visitado.
 B) Tiempo de inicialización y valor bajo
 C) Ir a través de todos los vértices adyacentes a este
 Comprobar si el subárbol enraizado con x tiene una conexión a uno de los antepasados de w.
 Si el vértice más bajo alcanzable desde el subárbol debajo de x está debajo de u en el árbol DFS, entonces w-x tiene un conexión.
 E) Actualice el valor bajo de w para las llamadas a funciones principales.

 funcion Connected_Components
 A) Marque todos los vértices como no visitados.
 B) Inicializar par y visitado, y conexiones.
 C) Imprime las conexiones entre los bordes en el gráfico.
 */