#include <iostream>
using namespace std;

const int MAX = 1000;

int f[MAX] = {0};

int fib(int n)
{

    if (n == 0)
        return 0;
    if (n == 1 || n == 2)
        return (f[n] = 1);

    if (f[n])
        return f[n];

    int k = (n & 1) ? (n + 1) / 2 : n / 2;

    f[n] = (n & 1) ? (fib(k) * fib(k) + fib(k - 1) * fib(k - 1)): (2 * fib(k - 1) + fib(k)) * fib(k);
    return f[n];
}

int main()
{
    int n = 9;
    cout<<fib(n);
    return 0;
}

/*
 pasos para resolver el problema:
    1. crear un arreglo de enteros llamado f con una longitud de 1000 (MAX) y todos los elementos en 0
    2. crear una funcion que reciba un entero y retorne el fibonacci de ese numero (fib(n)) en el arreglo f (f[n]) si no se ha calculado antes
 */