#include<iostream>
#include <list>
using namespace std;


class Graph{
    int V;
    list<int> *adj;
public:
    Graph(int V);
    void addEdge(int v, int w);
    void printVertexCover();
};

Graph::Graph(int V){
    this->V = V;
    adj = new list<int>[V];
}

void Graph::addEdge(int v, int w){
    adj[v].push_back(w);
    adj[w].push_back(v);
}


void Graph::printVertexCover(){

    bool visited[V];
    for (int i=0; i<V; i++)
        visited[i] = false;

    list<int>::iterator i;


    for (int u=0; u<V; u++)
    {
        if (visited[u] == false)
        {
            for (i= adj[u].begin(); i != adj[u].end(); ++i)
            {
                int v = *i;
                if (visited[v] == false)
                {

                    visited[v] = true;
                    visited[u] = true;
                    break;
                }
            }
        }
    }

    for (int i=0; i<V; i++)
        if (visited[i])
            cout << i << " ";
}


int main()
{

    Graph g(7);
    g.addEdge(0, 1);
    g.addEdge(0, 2);
    g.addEdge(1, 3);
    g.addEdge(3, 4);
    g.addEdge(4, 5);
    g.addEdge(5, 6);

    g.printVertexCover();

}

/*
se reduce  el problema de Clique (se sabe que es np completo) a el problema de
la cobertura de vertices.

primero debemos saber si existe un clique de tamño k en el grafo dado, por lo que una instancia del problema del clique es un grafo G (V, E) y un número entero no negativo k, y necesitamos verificar la existencia de un clique de
tamaño k en G.

Ahora, se requiere mostrar que cualquier instancia (G, k) del problema Clique puede reducirse a una instancia del problema de cobertura de vértices.

 Considere el grafo G' que consta de todas las aristas no en G, sino en el grafo completo usando todos los vértices en G. Llamemos a esto el complemento de G. Ahora, el problema de encontrar si existe un clique de tamaño k en el grafo G es lo mismo que el problema de encontrar si hay una cubierta de vértice de tamaño |V| - K en G'. Tenemos que demostrar que esto es así.

Suponga que hay un clique de tamaño k en G. Sea V' el conjunto de vértices del clique. Esto significa |V'| = k. En el grafo complementario G', elijamos cualquier arista (u, v). Entonces al menos uno de uov debe estar en el conjunto V – V'. Esto se debe a que, si tanto u como v fueran del conjunto V', entonces la arista (u, v) pertenecería a V', lo que, a su vez, significaría que la arista (u, v) está en G. Esto es no es posible ya que (u, v) no está en G. Así, todas las aristas en G' están cubiertas por vértices en el conjunto V – V'.

Ahora suponga que hay una cubierta de vértice V'' de tamaño |V| - rey'. Esto significa que todas las aristas en G' están conectadas a algún vértice en V''. Por tanto, si tomamos cualquier arista (u, v) de G', ambas no pueden estar fuera del conjunto V''. Esto significa que todas las
aristas (u, v) tales que tanto u como v están fuera del conjunto V'' están en G, es decir, estas aristas constituyen un clique de tamaño k.

Por lo tanto, podemos decir que hay un clique de tamaño k en el grafo G si y solo si hay una cubierta de vértice de tamaño |V| – k en G' y, por lo tanto, cualquier instancia del problema del clique se puede reducir a una instancia del problema de cobertura de vértices. Por lo tanto, la cobertura de vértices es NP Hard. Dado que la cobertura de vértices está en las clases NP y NP Hard, es NP Complete.
*/