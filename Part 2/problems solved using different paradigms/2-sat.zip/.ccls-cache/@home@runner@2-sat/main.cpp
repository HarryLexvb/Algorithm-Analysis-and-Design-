#include <iostream>
#include <vector>
#include <stack>

using namespace std;

const int MAX = 100000;

vector<int> adj[MAX];
vector<int> adjInv[MAX];
bool visited[MAX];
bool visitedInv[MAX];
stack<int> s;
int scc[MAX];
int counter = 1;

void addEdges(int a, int b){
    adj[a].push_back(b);
}

void addEdgesInverse(int a, int b){
    adjInv[b].push_back(a);
}

void dfsFirst(int u){
    if(visited[u])
        return;
    visited[u] = 1;
    for (int i : adj[u])
        dfsFirst(i);
    s.push(u);
}

void dfsSecond(int u){
    if(visitedInv[u])
        return;
    visitedInv[u] = true;
    for (int i : adjInv[u])
        dfsSecond(i);
    scc[u] = counter;
}

void is2Satisfiable(int n, int m, int *a, int *b){
    for(int i=0;i<m;i++){
        if (a[i]>0 and b[i]>0){
            addEdges(a[i]+n, b[i]);
            addEdgesInverse(a[i]+n, b[i]);
            addEdges(b[i]+n, a[i]);
            addEdgesInverse(b[i]+n, a[i]);
        }

        else if (a[i]>0 && b[i]<0){
            addEdges(a[i]+n, n-b[i]);
            addEdgesInverse(a[i]+n, n-b[i]);
            addEdges(-b[i], a[i]);
            addEdgesInverse(-b[i], a[i]);
        }

        else if (a[i]<0 and b[i]>0){
            addEdges(-a[i], b[i]);
            addEdgesInverse(-a[i], b[i]);
            addEdges(b[i]+n, n-a[i]);
            addEdgesInverse(b[i]+n, n-a[i]);
        }
        else{
            addEdges(-a[i], n-b[i]);
            addEdgesInverse(-a[i], n-b[i]);
            addEdges(-b[i], n-a[i]);
            addEdgesInverse(-b[i], n-a[i]);
        }
    }
    for (int i=1;i<=2*n;i++)
        if (!visited[i])
            dfsFirst(i);

    while (!s.empty()){
        int n = s.top();
        s.pop();

        if (!visitedInv[n]){
            dfsSecond(n);
            counter++;
        }
    }

    for (int i=1;i<=n;i++){
        if(scc[i]==scc[i+n]){
            cout << "NO" << endl;
            return;
        }
    }
    cout << "YES" << endl;
}

int main(){
    int n = 5, m = 7;
    // Note:
    // 1 <= x <= N for an uncomplemented variable x
    // -N <= x <= -1 for a complemented variable x
    // -x is the complement of a variable x

    // The CNF being handled is:
    // '+' implies 'OR' and '*' implies 'AND'
    // (x1+x2)*(x2’+x3)*(x1’+x2’)*(x3+x4)*(x3’+x5)*
    // (x4’+x5’)*(x3’+x4)
    int a[] = {1, -2, -1, 3, -3, -4, -3};
    int b[] = {2, 3, -2, 4, 5, -5, 4};

    is2Satisfiable(n, m, a, b);
}

/*
CASO 1: Si edge(x -> ~x) existe en el grafo.
 Esto significa (X -> ~X)
 Si X = VERDADERO, ~X = VERDADERO, lo cual es una contradicción. Pero si X = FALSO, no hay restricciones de implicación. Por lo tanto, X = FALSO

 CASO 2: Si edge(~X -> X) existe en el grafo
 Esto significa (~  x -> x)
 Si ~X = VERDADERO, X = VERDADERO, lo cual es una contradicción.
 Pero si ~x = FALSO, no hay restricciones de implicación.
 Por lo tanto, ~x = FALSO, es decir, X = VERDADERO

 CASO 3: Si edge(x -> ~x)&edge(~x -> x) existen ambos en el grafo.
 Un borde requiere que X sea VERDADERO y el otro requiere que X sea FALSO.
 Por lo tanto, no hay asignación posible en tal caso.


 Input : n = 2, m = 3
        a[] = {1, 2, -1}
        b[] = {2, -1, -2}
Output : The given expression is satisfiable.

Input : n = 2, m = 4
        a[] = {1, -1, 1, -1}
        b[] = {2, 2, -2, -2}
Output : The given expression is unsatisfiable.
 */