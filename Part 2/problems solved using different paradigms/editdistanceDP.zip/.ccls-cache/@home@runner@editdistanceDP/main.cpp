#include <iostream>
#include <string>
#include <algorithm>
#include <cmath>

using ll = long long;
using std::string;

ll memo[101][101];

int edit_distance(const string& str1, const string& str2) {
    for (int i = 0; i < 101; ++i) {
        for (int j = 0; j < 101; ++j) {
            memo[i][j] = 2e9;
        }
    }

    for (int i = 0; i <= str1.size(); ++i)
        memo[i][0] = i;

    for (int i = 0; i <= str2.size(); ++i)
        memo[0][i] = i;

    for (int i = 1; i <= str1.size(); ++i) {
        for (int j = 1; j <= str2.size(); ++j) {
            memo[i][j] = std::min(memo[i - 1][j] + 1,
                                  std::min(memo[i][j - 1] + 1, memo[i - 1][j - 1] + (str1[i - 1] != str2[j - 1])));
        }
    }

    return memo[str1.size()][str2.size()];
}

int main() {
    string str1;
    string str2;
    std::cin >> str1 >> str2;
    std::cout << edit_distance(str1, str2) << std::endl;
    return 0;
}

/*
 

    para resolver edit_distance:
        1. crear una matriz de 100x100
        2. llenarla con 2e9
        3. llenar la primera fila y columna con 0
        4. llenar la matriz con la distancia de edicion entre str1 y str2
        5. imprimir la matriz

        para llenar la matriz, se usa un for que recorre las filas y columnas de la matriz.

        para llenar la primera fila y columna, se usa un for que recorre las columnas y filas de la matriz.

        para resolver edit_distance:
            1. crear una matriz de 100x100
            2. llenarla con 2e9
            3. llenar la primera fila y columna con 0
            4. llenar la matriz con la distancia de edicion entre str1 y str2
            5. imprimir la matriz

            para llenar la matriz, se usa un for que recorre las filas y columnas de la matriz.

            para llenar la primera fila y columna, se usa un for que recorre las columnas y filas de la matriz.

            para resolver edit_distance:
                1. crear una matriz de 100x100
                2. llenarla con 2e9
                3. llenar la primera fila y columna con 0
                4. llenar la matriz con la distancia de edicion entre str1 y str2
                5. imprimir la matriz

                para llenar la matriz, se usa un for que recorre las filas y columnas de la matriz.

                para llenar la primera fila y columna, se usa un for que recorre las columnas y filas de la matriz.


 */