#include <iostream>
#include <vector>

using namespace std;
//dp usando top-down
bool isSubsetSum_dp_top(int arr[], int n, int sum, vector<vector<int> >& dp){
    if (sum == 0)
        return true;
    if (n == 0 and sum != 0)
        return false;

    if (dp[n][sum] != -1)
        return dp[n][sum];

    if (arr[n - 1] > sum)
        return isSubsetSum_dp_top(arr, n - 1, sum, dp);

    return dp[n][sum] = isSubsetSum_dp_top(arr, n - 1, sum, dp) or isSubsetSum_dp_top(arr, n - 1, sum - arr[n - 1], dp);
}

bool findPartiion_dp_top(int arr[], int n){
    int sum = 0;
    for (int i = 0; i < n; i++)
        sum += arr[i];

    if (sum % 2 != 0)
        return false;

    vector<vector<int> > dp(n + 1,vector<int>(sum + 1, -1));

    return isSubsetSum_dp_top(arr, n, sum / 2, dp);
}

int main(){
    {
        int arr[] = {3, 1, 5, 9, 12};
        int n = sizeof(arr) / sizeof(arr[0]);

        // Function call
        if (findPartiion_dp_top(arr, n))
            cout << "YES" << endl; // si es posible dividir la matriz en dos subset con igual suma
        else
            cout << "NO" << endl; // no es posible dividir la matriz en dos subset con igual suma

    }

    {
        int arr[] = {3, 1, 5, 9, 14};
        int n = sizeof(arr) / sizeof(arr[0]);

        if (findPartiion_dp_top(arr, n))
            cout << "YES" << endl; // si es posible dividir la matriz en dos subset con igual suma
        else
            cout << "NO" << endl; // no es posible dividir la matriz en dos subset con igual suma
    }
}

/*
 pasos para resolver el problema:
    1. hallar el suma total de la matriz
    2. hallar el subset con suma total/2
    3. si el subset con suma total/2 es posible dividir la matriz en dos subset con igual suma
        3.1. si el subset con suma total/2 es posible dividir la matriz en dos subset con igual suma
            3.1.1. si el subset con suma total/2 es posible dividir la matriz en dos subset con igual suma


Complejidad del tiempo: O(suma*n)

 */

