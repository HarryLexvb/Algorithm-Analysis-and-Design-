#include <iostream>

using namespace std;


int binarySearch(int *arr, int l, int r, int x)
{
    if (r >= l) {
        int mid = l + (r - l) / 2;
        if (arr[mid] == x)
            return mid;

        if (arr[mid] > x)
            return binarySearch(arr, l, mid - 1, x);

        return binarySearch(arr, mid + 1, r, x);
    }

    return -1;
}

int main(){
    int arr[] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
    int n = sizeof(arr) / sizeof(arr[0]);
    int x = 10;
    int result = binarySearch(arr, 0, n - 1, x);
    if (result == -1)
        cout << "No se encontro el numero";
    else
        cout << "Se encontro el numero " << result;
    return 0;
}

/*
   pasos para bynary search
    1. divide el arreglo en 2 partes
    2. si el numero esta en la mitad del arreglo, entonces se encontro el numero
    3. si el numero esta en la primera mitad del arreglo, entonces se busca en la primera mitad del arreglo
    4. si el numero esta en la segunda mitad del arreglo, entonces se busca en la segunda mitad del arreglo
    5. si el numero no esta en el arreglo, entonces se busca en la mitad del arreglo que no contiene el numero

    complexity: O(log n)

 */