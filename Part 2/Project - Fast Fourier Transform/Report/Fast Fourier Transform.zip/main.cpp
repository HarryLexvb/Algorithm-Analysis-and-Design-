
void FFT_t(arr &v){
    int n = v.size();
    if(n > 1) {
        arr odd(n / 2);
        arr even(n / 2);
        for (int i = 0; 2 * i < n; ++i) {
            even[i] = v[2 * i];
            odd[i] = v[2 * i + 1];
        }
        FFT_t(even);
        FFT_t(odd);
        double ang = -2 * PI / n;
        x_n w(1.0);
        x_n wn(cos(ang), sin(ang));
        for (int k = 0; k < n / 2; ++k) {
            v[k] = even[k] + w * odd[k];
            v[k + n / 2] = even[k] - w * odd[k];
            w *= wn;
        }
    }
}

void IFFT_f(arr &v){
    v = v.apply(conj);
    FFT_t(v);
    v = v.apply(conj);
    v /= v.size();
}


