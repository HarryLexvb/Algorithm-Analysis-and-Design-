#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "2clsEq.h"
#include "preprocessor.h"
#include "utilities.h"

char * filename;
char * outfile = NULL; 

void gatherStats();

void usage() {
  printf("Preprocessor. Developed and written by Fahiem Bacchus, University of Toronto\n");
  printf("Usage: hypre -o [output cnf filename] [input cnf filename]\n");
  printf("  Additional flags: -v verbosity level (0 - 3)\n");
  exit(1);
}

#ifdef WIN32
int __cdecl main(int argc, char *argv[]) {
#else 
int main(int argc, char *argv[]) {
#endif
  if(argc == 1)
    usage();
  
  // Set default verbosity level to zero (silent).
  int level = 0;
  
  // Look for parameters.
  for(int i = 1; i < argc; i++) {
      // Check if the user provides a verbosity
    if(argv[i][0] == '-' && argv[i][1] == 'v') {
      i++;
      if((sscanf(argv[i], "%d", &level) != 1)
	 && (level >= 0) && (level <= 3))
	usage();
    }
    // Check if user provided name for the output cnf.
    else if(argv[i][0] == '-' && argv[i][1] == 'o') {
      i++;
      outfile = argv[i];
    }
    // Otherwise, assume the argument is the input filename.
    else
      filename=argv[i];
    }
  
#ifdef WIN32
  DetectPlatform();
#endif /* WIN32 */
  
  CONTRADICTION.val=false;
  if(!readProblem(filename)) {
      printf("c Problem reading CNF file.\n");
      exit(1);
  }
  
  start_time = GetInternalRunTime();
 
  if(strchr(filename,'/'))
    filename=strrchr(filename, '/')+1;
  else if(strchr(filename,'\\'))
    filename=strrchr(filename, '\\')+1;
  preprocessor();

  // This function's work is now performed in the beginning of cnfoutput().
  //gatherStats();
  if(!CONTRADICTION.val)
    cnfoutput();
  
    //temp
  //fprintReducedTheory();
  

  end_time = GetInternalRunTime();

  printSummary();
  recordSummary();

  return(0);
}
