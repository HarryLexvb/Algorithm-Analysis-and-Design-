//
// FILE: modelcheck.cpp
//

// OVERVIEW:
//
// This file takes as input a v-line file and a cnf file.  It then checks
// whether the truth assignment in the vline file satisfies the cnf files
// theory.

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define _DEBUG

class bucket {
public:
  int lit;
  bool value;
  bucket * next;
};

int NVARS;
bucket * assignments;
bucket * freeBuckets;
bucket * nextFreeBucket;

void addAssignment(int lit, bool value) {
  if(assignments[lit % NVARS].lit == 0) {
    assignments[lit % NVARS].lit = lit;
    assignments[lit % NVARS].value = value;
    assignments[lit % NVARS].next = NULL;
  }
  else if(assignments[lit % NVARS].lit != lit) {
    bucket * temp = assignments + (lit % NVARS);
    while(temp->next != NULL) {
      if(temp->next->lit == lit) {
	printf("ERROR: Attempted to add literal twice to hashtable.\n");
	exit(1);
      }
      else
	temp = temp->next;
    }
    temp->next = nextFreeBucket++;
    temp->next->lit = lit;
    temp->next->value = value;
    temp->next->next = NULL;
  }
  else {
    printf("ERROR: Attempted to add literal twice to hashtable.\n");
    exit(1); 
  }
}
 
bool getValue(int lit) {
  if(assignments[lit % NVARS].lit == lit)
    return(assignments[lit % NVARS].value);

  // Hashtable entry should not be empty.
  else if(assignments[lit % NVARS].lit == 0) {
    printf("ERROR: Could not find lit %d in hastable.\n", lit);
    exit(1);
  }
  else {
    bucket * temp = assignments[lit % NVARS].next;
    while(temp != NULL) {
      if(temp->lit == lit)
	return(temp->value);
      else
	temp = temp->next;
    }
    // Should not reach here.
    printf("ERROR: Could not find lit %d in hastable.\n", lit);
    exit(1);
  }
}
 
void printAssignments() {
  int i;
  
  printf("\nHere are the variable assignments\n");
  for(i = 0; i < NVARS; i++) {
    if(assignments[i].lit != 0) {
      if(assignments[i].value)
	printf("%d: %d (T)", i, assignments[i].lit);
      else
	printf("%d: %d (F)", i, assignments[i].lit);
      
      bucket * temp = assignments[i].next;
      while(temp != NULL) {
	if(temp->value)
	  printf(", %d (T)", temp->lit);
	else
	  printf(", %d (F)", temp->lit);
	temp = temp->next;
      }
      printf("\n");
    }
  }
}


void usage() {
  printf("Usage: modelcheck [input vline file] [input cnf file]\n"); 
  exit(1);
}

#ifdef WIN32
int __cdecl main(int argc, char *argv[]) {
#else 
int main(int argc, char *argv[]) {
#endif

  int i, lit, retval;
  char * vline_filename;
  char * cnf_filename;
  int NCLAUSES;
  FILE * vfp;
  FILE * cfp;
  char ch;
  char word[81];
  //bool * assignments;

  if(argc == 1)
    usage();

  vline_filename = argv[1];
  cnf_filename = argv[2];

  if((vfp = fopen(vline_filename, "r")) == NULL) {
    printf("ERROR: Could not open file named %s.\n", vline_filename);
    usage();
  }

  if((cfp = fopen(cnf_filename, "r")) == NULL) {
    printf("ERROR: Could not open file named %s.\n", cnf_filename);
    usage();
  }

  // Look through the cnf file to find the number of variables and 
  // number of clauses.  They will be found on the  parameter line
  // which starts with the letter 'p'.
  while((retval = fscanf(cfp, "%c", &ch)) && (ch != 'p')) {
    if((retval == EOF) || feof(cfp)) {
      printf("ERROR: Could not find parameter line in cnf file.\n");
      fclose(vfp);
      fclose(cfp);
      exit(0);
    }
    while(fscanf(cfp, "%c", &ch) && (ch != '\n'))
      ;
  }

  if(!fscanf(cfp, "%s%d%d", word, &NVARS, &NCLAUSES)) {
    printf("ERROR: problem finding parameter line in cnf file %s.",
	   cnf_filename);
    exit(1);
  }

  if(NVARS < 0 || NCLAUSES < 0) {
    printf("Illegal parameters specified, #vars = %d, #clauses = %d!\n",
		   NVARS, NCLAUSES);
    exit(1);
  }
  
  // Initialize hashtable for storing variable assignments.
  assignments = new bucket[NVARS];
  for(i = 0; i < NVARS; i++)
    assignments[i].lit = 0;

  freeBuckets = new bucket[NVARS];
  nextFreeBucket = freeBuckets;

  //assignments = new bool[NVARS+1];

  // Find the line containing the variable assignments in the vline.
  // It starts with the letter 'v'.
  while((retval = fscanf(vfp, "%c", &ch)) && (ch != 'v')) {
    if((retval == EOF) || feof(vfp)) {
      printf("ERROR: Could not find the v-line in file.\n");
      fclose(vfp);
      fclose(cfp);
      exit(0);
    }
    while(fscanf(vfp, "%c", &ch) && (ch != '\n'))
      ;
  }

  for(i = 1; i <= NVARS; i++) {
    fscanf(vfp, "%d", &lit);

    if(lit > 0)
      //assignments[i] = true;
      addAssignment(lit, true);
    else
      //assignments[i] = false;
      addAssignment(abs(lit), false);
  }

#ifdef _DEBUG
  fscanf(vfp, "%d", &lit);
  if(lit != 0)
    printf("ERROR: More variables than expected in v-line file!\n");
#endif // _DEBUG

  //printAssignments();

  // Now go through clauses in cnf file and make sure they are all
  // satisfied.
  for(i = 0; i < NCLAUSES; i++) {
    while((retval = fscanf(cfp, "%d", &lit)) != 0) {
      if((retval == EOF) || feof(cfp)) {
	printf("The vline file %s SATISFIES the cnf file %s.\n", vline_filename,
	       cnf_filename);
	fclose(vfp);
	fclose(cfp);
	exit(0);
      }
      else if(lit == 0) {
	printf("Clause %d not satisfied.\n", i + 1);
	printf("The vline file %s DOES NOT SATISFY the cnf file %s.\n", vline_filename,
	       cnf_filename);
	fclose(vfp);
	fclose(cfp);
	exit(0);
      }
      // Check if this literal satisfies the clause.
      //else if(((lit > 0) && assignments[lit]) || ((lit < 0) && !assignments[abs(lit)])) {
      else if(((lit > 0) && getValue(lit)) || ((lit < 0) && !getValue(abs(lit)))) {
	// Go to next clause.
	while(fscanf(cfp, "%c", &ch) && (ch != '\n') && !feof(cfp));

	break;
      }
    }
  }

  printf("The vline file %s SATISFIES the cnf file %s.\n", vline_filename,
	 cnf_filename);

  fclose(vfp);
  fclose(cfp);
}
