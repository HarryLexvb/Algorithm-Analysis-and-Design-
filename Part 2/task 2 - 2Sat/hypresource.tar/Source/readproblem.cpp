/*Readproblem. Read a DIMACS standard CNF File.*/
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "2clsEq.h"
#include "uniqueset.h"
#include "utilities.h"

bool *renum_varused;
int  *renum_varnum;
int  *orig_varnum;

const int MAXWORD=256;

int NVARS, NCLAUSES, NLITS, LITSINCLAUSES, NACTIVELITS;
CLAUSELIST *lenNclauses[CLSGROUPS];

bool readProblem(char *input_file) {
  FILE* fp;
  char ch;
  int lit, clslen;
  CLAUSELIST *clsptr;
  int maxclause[MAXCLAUSELEN];
  int i,j;
  char word[MAXWORD];

  for(i=0;i<CLSGROUPS;i++) {
    lenNclauses[i]=NULL; 
  }

  if(!(fp = fopen(input_file, "r"))) return false;
  
  //find the parameter line. A line starting with 'p'
  while(fscanf(fp,"%c",&ch) && ch!='p') 
    while(fscanf(fp,"%c",&ch) && ch!='\n')
      ;
  
  if(!fscanf(fp, "%s%d%d", word, &NVARS, &NCLAUSES)) {
    printf("Problems finding parameter line in input %s", input_file);
    return false;
  }
  if(NVARS < 0 || NCLAUSES < 0) {
    printf("Illegal parameters specified, #vars = %d, #clauses = %d!\n",
		   NVARS, NCLAUSES);
    return false;
  }

  int retval;
  for(i=0;i<NCLAUSES;i++) {
    clslen=0;
    while((retval=fscanf(fp, "%d", &lit))&&lit) {
      if(abs(lit) < 1 || abs(lit) > NVARS) {
		printf("Read illegal literal %d in file, #vars = %d!\n",
			   lit, NVARS);
		return false;
      }
      maxclause[clslen++]=to_internal(lit);
    }
    if(retval==EOF) {
      NCLAUSES=i;
      break;
    }

    //test for various reductions.
    if(clslen==0) {
      setContradiction();
      return true;
    }
	//
	int *cls = new int[clslen];
	if(!cls)
	  panic("Memory Allocation Failure #21\n");
	int reallen=0;
	bool tautology=false;
	for(j=0;j<clslen;j++) {
	  if(member(maxclause[j],cls,reallen))
	    //printf("R");
	    continue;
	  else if(member(negate(maxclause[j]),cls,reallen)) {
	    //printf("T");
	    tautology=true;
	    break;
	  }
	  else
	    cls[reallen++]=maxclause[j];
	}
	
	if(!tautology) {
	  int clsgrp = (reallen<CLSGROUPS)?reallen:CLSGROUPS-1;
	  clsptr = lenNclauses[clsgrp];
	  lenNclauses[clsgrp] = new CLAUSELIST;
	  if(!lenNclauses[clsgrp])
	    panic("Memory Allocation Failure #22\n");
	  lenNclauses[clsgrp]->cls = cls;
	  lenNclauses[clsgrp]->clslen=reallen;
	  lenNclauses[clsgrp]->active=true;
	  lenNclauses[clsgrp]->pnext=clsptr;
	}
  }
  
  int bcls=0;
  for(clsptr=lenNclauses[2];clsptr;clsptr=clsptr->pnext)
    bcls++;

  printf("c Inital problem has %d variables, %d nary clauses (%d binary clauses).\n",
		 NVARS,NCLAUSES-bcls,bcls);

  int Tlen=0;
  int Acls=0;

  for(i=3;i<CLSGROUPS;i++) {
    for(clsptr=lenNclauses[i];clsptr;clsptr=clsptr->pnext) 
      if(clsptr->active) {
		Acls++;
		Tlen+=clsptr->clslen;
      }
  }

  //@JON My additions
  extern int NUMNCLS;
  NUMNCLS = Acls;
  //@JON End of my addtions

  printf("c Num non-binary clauses %d, Average non-binary clause length %2.3f\n",Acls, (Acls>0? (Tlen*1.0)/Acls:0));

  //renumber the literals.
  renum_varused = new bool[NVARS];
  renum_varnum = new int[NVARS];
  orig_varnum = new int[NVARS];
  if(!renum_varused || !renum_varnum || !orig_varnum)
	panic("Memory Allocation Failure #23\n");
  for(i=0;i<NVARS;i++) {
    renum_varnum[i]=i;
	orig_varnum[i]=i;
    renum_varused[i]=false;
  }

  //mark the used vars
  for(i=0;i<CLSGROUPS;i++)
    for(clsptr=lenNclauses[i];clsptr;clsptr=clsptr->pnext)
      for(j=0;j<clsptr->clslen;j++)
		renum_varused[variable_of(clsptr->cls[j])]=true;
  
  //number them
  j=0;
  for(i=0;i<NVARS;i++) {
	renum_varnum[i]=j;

	if(renum_varused[i]) {
	  orig_varnum[j]=i;
	  j++;
	}
  }
  
  if(j!=NVARS) {
	//FILE* fpnew;
    //fpnew=fopen("_renumbered.cnf", "w");
    //print map
    //fprintf(fpnew,"c\n");
    //for(i=0;i<NVARS;i++)
    //if(renum_varused[i]) 
	//fprintf(fpnew,"cV%d==>%d\n", i+1, renum_varnum[i]+1);
    
    NVARS=j;
    //now renumber the clauses
    for(i=0;i<CLSGROUPS;i++)
      for(clsptr=lenNclauses[i];clsptr;clsptr=clsptr->pnext)
		for(j=0;j<clsptr->clslen;j++)
		  clsptr->cls[j]=to_literal(renum_varnum[variable_of(clsptr->cls[j])],
									truth_of(clsptr->cls[j]));
    
    //now print them out.
    
    //fprintf(fpnew,"c NEW theory.\n");
    //fprintf(fpnew,"p cnf %d %d \n", NVARS,  NCLAUSES);
    //for(i=0;i<CLSGROUPS;i++)
    //  for(clsptr=lenNclauses[i];clsptr;clsptr=clsptr->pnext) {
	//	for(j=0;j<clsptr->clslen;j++)
	//	  fprintf(fpnew,"%d ",to_ff(clsptr->cls[j]));
	//	fprintf(fpnew,"0\n");
    //  }
    //fclose(fpnew);
  }
  else 
    printf("c Theory has no gaps\n");

  delete[] renum_varused;
  delete[] renum_varnum;

  NLITS=NVARS*2;
  return true;
}
