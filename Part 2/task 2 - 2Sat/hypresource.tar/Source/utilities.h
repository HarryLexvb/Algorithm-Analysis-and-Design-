#ifndef __utilities_H
#define __utilities_H

class Contradiction {
public:
  bool val;
  Contradiction() {
    val=false;
  };
};

extern Contradiction CONTRADICTION;

bool member(int l, int* array, int len);
void DetectPlatform();
double GetInternalRunTime();

inline void setContradiction() {
    CONTRADICTION.val=true;
}

inline bool haveContradiction() {
  return(CONTRADICTION.val);
};

#endif /* __utilities_H */
